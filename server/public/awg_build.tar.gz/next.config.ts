import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  typescript: { ignoreBuildErrors: true },
  productionBrowserSourceMaps: false,
  async rewrites() {
    return [{ source: "/api/:path*", destination: "http://localhost:8000/api/:path*" }];
  },
  webpack: (config, { isServer }) => {
    if (!isServer) config.parallelism = 1;
    return config;
  },
};
export default nextConfig;
