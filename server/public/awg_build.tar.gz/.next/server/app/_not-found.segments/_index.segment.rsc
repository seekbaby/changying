1:"$Sreact.fragment"
2:I[7121,[],""]
3:I[4581,[],""]
:HL["/_next/static/css/3ab1876ff8ad21b2.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/3ab1876ff8ad21b2.css","precedence":"next"}]],["$","html",null,{"lang":"zh-CN","className":"h-full","children":["$","body",null,{"className":"h-full overflow-hidden bg-gray-50 text-gray-900 antialiased","children":["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"JS0S4RYwgWhYcijTUi7n-"}
