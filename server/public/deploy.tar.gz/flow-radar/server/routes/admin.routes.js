/**
 * REST API 路由（非WebSocket操作的管理接口）
 */
const express = require('express');
const { adminGuard } = require('../middleware/adminGuard.middleware');
const staffService = require('../services/staff.service');
const roomService = require('../services/room.service');
const adminService = require('../services/admin.service');
const { db } = require('../database/init');

const router = express.Router();

// ── 健康检查 ──
router.get('/health', (req, res) => {
  res.json({ status: 'ok', time: Date.now() });
});

// ── 公开端点：人员列表（id/name/role/department/pin）──
router.get('/staff', (req, res) => {
  const all = db.prepare('SELECT id, name, role, department, pin FROM staff WHERE is_active = 1 ORDER BY role, id').all();
  res.json(all);
});

// ── 管理员API（需要验证）──
// 所有 /api/admin/* 都需要管理员密码或token
router.use('/admin', adminGuard);

router.get('/admin/staff', (req, res) => {
  const all = db.prepare('SELECT * FROM staff ORDER BY role, id').all();
  res.json(all);
});

router.post('/admin/staff', (req, res) => {
  const staff = staffService.create(req.body);
  res.json(staff);
});

router.put('/admin/staff/:id', (req, res) => {
  const staff = staffService.update(parseInt(req.params.id), req.body);
  res.json(staff);
});

router.get('/admin/rooms', (req, res) => {
  const all = db.prepare('SELECT * FROM rooms ORDER BY sort_order').all();
  res.json(all);
});

router.post('/admin/rooms', (req, res) => {
  const room = roomService.create(req.body);
  res.json(room);
});

router.put('/admin/rooms/:id', (req, res) => {
  const room = roomService.update(parseInt(req.params.id), req.body);
  res.json(room);
});

router.get('/admin/operations', (req, res) => {
  const ops = adminService.getOperations(parseInt(req.query.limit) || 50);
  res.json(ops);
});

router.get('/admin/transitions', (req, res) => {
  const all = db.prepare('SELECT * FROM status_transitions ORDER BY id').all();
  res.json(all);
});

module.exports = router;
